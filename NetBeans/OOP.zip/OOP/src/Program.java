import java.util.ArrayList;

public class Program {

	public static void main(String[] args) {
		Mitarbeiter m1 = new Mitarbeiter();
		Mitarbeiter m2 = new Mitarbeiter();
		
		m1.setNachname( "Mustermann" );
		m1.setVorname( "Max" );
		m1.setArbeitsStunden( 40 );
		Mitarbeiter.gemeinschaftsKasse += 100;
		
		m2.setNachname( "Musterfrau" );
		m2.setVorname( "Maxi" );
		m2.setArbeitsStunden( 35 );
		Mitarbeiter.gemeinschaftsKasse -= 20;
		
		System.out.println(m1.getNachname() + m1.getVorname() + m1.getArbeitsStunden());
		System.out.println(m2.getNachname() + m2.getVorname() + m2.getArbeitsStunden());
		
		System.out.println(Mitarbeiter.gemeinschaftsKasse);
		

		Angestellte ang = new Angestellte();
		ang.setNachname("MusterAngestellter");
		ang.setGehalt(2000);
		
		Arbeiter arb = new Arbeiter();
		arb.setNachname("MusterArbeiter");
		arb.setStundenLohn(20);
		arb.setArbeitsStunden(40);
		
		ArrayList<Mitarbeiter> mitarbeiterListe = new ArrayList<Mitarbeiter>();
		mitarbeiterListe.add(ang);
		mitarbeiterListe.add(arb);
		
		for(Mitarbeiter m : mitarbeiterListe){
			if(m instanceof Angestellte)
				System.out.println( m.getNachname() + " : " + ((Angestellte)m).getGehalt());
			else if(m instanceof Arbeiter)
				System.out.println( m.getNachname() + " : " + ((Arbeiter)m).getStundenLohn() * m.getArbeitsStunden() * 4);
		}
		
		// Polymorphie / polymorphes Verhalten
		System.out.println("Ausabe der toString-Methode");
		for(Mitarbeiter m : mitarbeiterListe)
			System.out.println( m );
		
	}
}
