
public class Angestellte extends Mitarbeiter {
	private double gehalt;

	@Override
	public String toString() {
		return "Angestellte: " + this.getNachname() + " verdient " + this.gehalt;
	}
	
	public double getGehalt() {
		return gehalt;
	}

	public void setGehalt(double gehalt) {
		this.gehalt = gehalt;
	}
	
}
