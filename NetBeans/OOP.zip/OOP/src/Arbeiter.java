
public class Arbeiter extends Mitarbeiter{
	private double stundenLohn;

	@Override
	public String toString() {
		return "Arbeiter: " + this.getNachname() + " verdient " + this.getArbeitsStunden() * this.stundenLohn * 4;
	}
	
	public double getStundenLohn() {
		return stundenLohn;
	}

	public void setStundenLohn(double stundenLohn) {
		this.stundenLohn = stundenLohn;
	}
	
}
