
public class Mitarbeiter {
	private String nachname;
	private String vorname;
	private int arbeitsStunden;
	
	@Override
	public String toString() {
		return "Mitarbeiter: " + this.nachname;
	}
	
	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		
		this.nachname = nachname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public int getArbeitsStunden() {
		return arbeitsStunden;
	}

	public void setArbeitsStunden(int arbeitsStunden) {
		this.arbeitsStunden = arbeitsStunden;
	}

	static double gemeinschaftsKasse;
	// final int ZAHL = 100; // Konstante
}
