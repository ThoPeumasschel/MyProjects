import java.util.Scanner;

public class Program {

	static String[][] kundenArray = new String[100][3];
	static int z; // Anzahl Kunden
	
	public static void main(String[] args) {
		byte menu = 0;
		do{
			System.out.println("1 - Kunde anlegen");
			System.out.println("2 - Kunden ausgeben");
			System.out.println("3 - Anwendung beenden");
			
			menu = new Scanner(System.in).nextByte();
			
			switch (menu) {
			case 1:
				kundenAnlegen();
				break;
			case 2:
				kundenAusgeben();
				break;
			case 3:
				System.out.println("Anwendung wird beendet");
				break;
			default:
				break;
			}
		
		}while(menu != 3);

	}
	
	static void kundenAnlegen(){
		// nr, nachname, vorname
		System.out.println("Kundennummer:");
		String nr = new Scanner(System.in).nextLine();
		System.out.println("Nachname:");
		String nachname = new Scanner(System.in).nextLine();
		System.out.println("Vorname:");
		String vorname = new Scanner(System.in).nextLine();
		
		kundenArray[z][0] = nr;
		kundenArray[z][1] = nachname;
		kundenArray[z][2] = vorname;
		
		z++;
		// 0 = nr
		// 1 = nachname
		// 2 = vorname
		
	}
	
	static void kundenAusgeben(){
		
		for (int i = 0; i < z; i++) {
			System.out.println( "Kundennr: " + kundenArray[i][0] + " Nachname: " + kundenArray[i][1] + " Vorname: " + kundenArray[i][2] );
		}
		
		/*
		for (int i = 0; i < z; i++) {
			for(int j = 0; j < 3; j++ ){
				System.out.print(kundenArray[i][j]);
			}
			System.out.println();
		}
		*/
		
		
	}

}
