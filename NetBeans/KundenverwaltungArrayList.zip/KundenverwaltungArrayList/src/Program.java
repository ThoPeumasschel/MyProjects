import java.util.ArrayList;
import java.util.Scanner;

public class Program {

	static ArrayList<String[]> kundenListe = new ArrayList<String[]>();
	
	
	public static void main(String[] args) {
		// Exkurs ArrayList
		/*
		ArrayList liste1 = new ArrayList();
		liste1.add("Mustermann");
		liste1.add(123456);
		liste1.add(kundenArray);
		
		//System.out.println(liste1.get(0));
		for(Object o : liste1){
			System.out.println(o);
		}
		
		ArrayList<String> liste2 = new ArrayList<String>();
		liste2.add("test");
		for(String o : liste2){
			System.out.println(o);
		}
		*/
		
		byte menu = 0;
		do{
			System.out.println("1 - Kunde anlegen");
			System.out.println("2 - Kunden ausgeben");
			System.out.println("3 - Anwendung beenden");
			
			menu = new Scanner(System.in).nextByte();
			
			switch (menu) {
			case 1:
				kundenAnlegen();
				break;
			case 2:
				kundenAusgeben();
				break;
			case 3:
				System.out.println("Anwendung wird beendet");
				break;
			default:
				break;
			}
		
		}while(menu != 3);
		
	}
	
	static void kundenAnlegen(){
		// nr, nachname, vorname
		System.out.println("Kundennummer:");
		String nr = new Scanner(System.in).nextLine();
		System.out.println("Nachname:");
		String nachname = new Scanner(System.in).nextLine();
		System.out.println("Vorname:");
		String vorname = new Scanner(System.in).nextLine();
		
		String[] kunde = new String[3];
		
		kunde[0] = nr;
		kunde[1] = nachname;
		kunde[2] = vorname;
		// 0 = nr
		// 1 = nachname
		// 2 = vorname
		kundenListe.add(kunde);
		
		
	}
	
	static void kundenAusgeben(){
		
		for(String[] daten: kundenListe){
			System.out.println(daten[0] + " - " + daten[1] + " - " + daten[2]);
		}
		
		
	}

}
