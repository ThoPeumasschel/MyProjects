
public class Test {
	int zahl;
	
	void testMethode(){
		System.out.println( this.zahl );
	}
	
}
