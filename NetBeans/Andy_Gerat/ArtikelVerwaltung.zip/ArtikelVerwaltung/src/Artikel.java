
public class Artikel {
	String nr;
	String bezeichnung;
	double preis;
	
	// Standard Konstruktor
	//public Artikel(){
		
	//}
	
	public Artikel(String nr, String bezeichnung, double preis){
		this.nr = nr;
		this.bezeichnung = bezeichnung;
		this.preis = preis;
	}
	
	
}
