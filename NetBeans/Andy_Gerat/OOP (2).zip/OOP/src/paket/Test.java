package paket;

public class Test {
	int x;
	public int y;
	private int z;
	
}
